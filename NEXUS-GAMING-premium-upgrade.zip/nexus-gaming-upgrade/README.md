# NEXUS GAMING — Premium Dark Glass Upgrade

Responsive gaming landing page with game search, genre filters, favorites, sorting, a number guessing mini-game, a Supabase-backed cumulative visit counter, and Supabase Realtime Presence for live connected sessions.

## Files
- `index.html` — site structure
- `css/style.css` — responsive premium dark-glass design
- `js/script.js` — UI interactions and Supabase counters
- `supabase-setup.sql` — SQL to create a shared visit counter

## Configure real visitor stats
1. Create a Supabase project at https://supabase.com/.
2. Open **SQL Editor**, create a query, paste `supabase-setup.sql`, and run it.
3. In the Supabase project dashboard, open **Project Settings / API** (or the Connect dialog) and copy the Project URL and the browser-safe **publishable key** (`sb_publishable_...`). A legacy `anon` key is also intended for browser use if your project still uses it.
4. Open `js/script.js` and replace:
   - `YOUR_SUPABASE_PROJECT_URL`
   - `YOUR_SUPABASE_PUBLISHABLE_KEY`
5. In Supabase Realtime settings, allow public access to channels if your project restricts public channels. This page uses a public Presence channel named `nexus-gaming-live-visitors`.
6. Test the page in two separate browser sessions. The live count should change as sessions connect/disconnect. The total count is shared in the database and increments once per tab session (sessionStorage).
7. Commit all files to the root of the `Gaming` GitHub repository and enable GitHub Pages from `main` / `(root)`.

## Security and accuracy notes
- Never put a Supabase secret key or `service_role` key in browser JavaScript.
- The live count represents connected browser sessions, not verified unique people. It can briefly lag while network disconnects time out.
- The total counter is persistent and shared, but the anonymous RPC can be spammed by a determined user. For a high-traffic or production site, put visit recording behind a rate-limited Edge Function or other server-side abuse controls.
- The cumulative counter counts a tab session once, not every page reload in that same tab session. Clearing session storage or opening another tab can create another counted visit.
- If the configuration is missing, the UI shows a setup message/dash instead of inventing a number.

## Publish
Expected URL after GitHub Pages is enabled and deployment completes:
https://Raja-kumar-1996.github.io/Gaming/
