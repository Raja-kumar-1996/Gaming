-- NEXUS GAMING visitor counter setup for Supabase SQL Editor.
-- The table is not directly readable/writable by anonymous browser users.
-- The two small RPC functions expose only the intended counter operations.

create table if not exists public.nexus_site_stats (
  id text primary key,
  total_visits bigint not null default 0 check (total_visits >= 0)
);

insert into public.nexus_site_stats (id, total_visits)
values ('nexus-gaming', 0)
on conflict (id) do nothing;

alter table public.nexus_site_stats enable row level security;
revoke all on table public.nexus_site_stats from anon, authenticated;
revoke all on table public.nexus_site_stats from public;

create or replace function public.increment_site_visits()
returns bigint
language plpgsql
security definer
set search_path = ''
as $$
declare
  new_total bigint;
begin
  update public.nexus_site_stats
  set total_visits = total_visits + 1
  where id = 'nexus-gaming'
  returning total_visits into new_total;

  if new_total is null then
    raise exception 'NEXUS GAMING counter row is missing';
  end if;

  return new_total;
end;
$$;

create or replace function public.get_site_visits()
returns bigint
language sql
security definer
set search_path = ''
as $$
  select total_visits
  from public.nexus_site_stats
  where id = 'nexus-gaming';
$$;

revoke all on function public.increment_site_visits() from public;
revoke all on function public.get_site_visits() from public;
grant execute on function public.increment_site_visits() to anon, authenticated;
grant execute on function public.get_site_visits() to anon, authenticated;
