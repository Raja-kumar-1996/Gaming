/* NEXUS GAMING
   Supabase URL + publishable key go below. Never put a secret/service_role key in browser code. */
const SUPABASE_URL = "YOUR_SUPABASE_PROJECT_URL";
const SUPABASE_PUBLISHABLE_KEY = "YOUR_SUPABASE_PUBLISHABLE_KEY";

const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];

const menuToggle = $("#menuToggle");
const navLinks = $("#navLinks");
menuToggle?.addEventListener("click", () => {
  const open = navLinks.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(open));
});
$$(".nav-links a").forEach(link => link.addEventListener("click", () => {
  navLinks.classList.remove("open");
  menuToggle?.setAttribute("aria-expanded", "false");
}));

$("#year").textContent = new Date().getFullYear();

const cards = $$(".game-card");
const searchInput = $("#gameSearch");
const filterButtons = $$(".filter-btn");
const sortSelect = $("#sortGames");
const emptyState = $("#emptyState");
let activeFilter = "all";
const favorites = new Set(JSON.parse(localStorage.getItem("nexus-favorites") || "[]"));

function paintFavorites() {
  cards.forEach(card => {
    const isFavorite = favorites.has(card.dataset.name);
    const button = $("[data-details]", card)?.parentElement?.querySelector(".favorite-btn");
    if (!button) return;
    button.classList.toggle("is-favorite", isFavorite);
    button.textContent = isFavorite ? "♥" : "♡";
    button.setAttribute("aria-pressed", String(isFavorite));
    button.setAttribute("aria-label", `${isFavorite ? "Remove" : "Add"} ${card.dataset.name} ${isFavorite ? "from" : "to"} favorites`);
  });
}

function filterAndSortGames() {
  const query = searchInput.value.trim().toLowerCase();
  const ordered = [...cards].sort((a, b) => {
    if (sortSelect.value === "az") return a.dataset.name.localeCompare(b.dataset.name);
    if (sortSelect.value === "za") return b.dataset.name.localeCompare(a.dataset.name);
    return cards.indexOf(a) - cards.indexOf(b);
  });
  ordered.forEach(card => {
    const matchesText = card.dataset.name.toLowerCase().includes(query) ||
      card.dataset.genre.toLowerCase().includes(query) ||
      card.querySelector(".game-info > p").textContent.toLowerCase().includes(query);
    const matchesFilter = activeFilter === "all" ||
      (activeFilter === "favorites" ? favorites.has(card.dataset.name) : card.dataset.genre === activeFilter);
    card.hidden = !(matchesText && matchesFilter);
    $("#gamesGrid").appendChild(card);
  });
  emptyState.hidden = cards.some(card => !card.hidden);
}
filterButtons.forEach(button => button.addEventListener("click", () => {
  activeFilter = button.dataset.filter;
  filterButtons.forEach(item => item.classList.toggle("active", item === button));
  filterAndSortGames();
}));
searchInput.addEventListener("input", filterAndSortGames);
sortSelect.addEventListener("change", filterAndSortGames);
cards.forEach(card => {
  $(".favorite-btn", card).addEventListener("click", () => {
    const name = card.dataset.name;
    favorites.has(name) ? favorites.delete(name) : favorites.add(name);
    localStorage.setItem("nexus-favorites", JSON.stringify([...favorites]));
    paintFavorites();
    filterAndSortGames();
  });
});
paintFavorites();

const gameDialog = $("#gameDialog");
cards.forEach(card => $("[data-details]", card).addEventListener("click", () => {
  $("#dialogTitle").textContent = card.dataset.name;
  $("#dialogDescription").textContent = card.dataset.description;
  $("#dialogGenre").textContent = card.dataset.genre.toUpperCase();
  $("#dialogRating").textContent = `★ ${card.dataset.rating}`;
  gameDialog.showModal();
}));
$("#closeDialog").addEventListener("click", () => gameDialog.close());
$("#dialogDone").addEventListener("click", () => gameDialog.close());
gameDialog.addEventListener("click", event => {
  if (event.target === gameDialog) gameDialog.close();
});

/* Number guessing mini-game */
let secretNumber, attempts;
function newRound() {
  secretNumber = Math.floor(Math.random() * 20) + 1;
  attempts = 0;
  $("#guessInput").value = "";
  $("#guessInput").disabled = false;
  $("#guessInput").focus({ preventScroll: true });
  $("#guessMessage").textContent = "Ready when you are.";
}
$("#guessForm").addEventListener("submit", event => {
  event.preventDefault();
  const input = $("#guessInput");
  const guess = Number(input.value);
  if (!Number.isInteger(guess) || guess < 1 || guess > 20) {
    $("#guessMessage").textContent = "Enter a whole number from 1 to 20.";
    return;
  }
  attempts++;
  if (guess === secretNumber) {
    $("#guessMessage").textContent = `You got it in ${attempts} ${attempts === 1 ? "try" : "tries"}! Nice work.`;
    input.disabled = true;
  } else if (attempts >= 6) {
    $("#guessMessage").textContent = `Round over — the number was ${secretNumber}. Try again!`;
    input.disabled = true;
  } else {
    $("#guessMessage").textContent = `${guess < secretNumber ? "Go higher" : "Go lower"} — ${6 - attempts} ${6 - attempts === 1 ? "try" : "tries"} left.`;
    input.select();
  }
});
$("#resetGuess").addEventListener("click", newRound);
newRound();

/* Real shared visitor stats: Supabase database RPC + Realtime Presence. */
const liveEl = $("#liveVisitors");
const totalEl = $("#totalVisits");
const liveStatus = $("#liveStatus");
const totalStatus = $("#totalStatus");
const configured = SUPABASE_URL.startsWith("https://") &&
  !SUPABASE_URL.includes("YOUR_SUPABASE") &&
  SUPABASE_PUBLISHABLE_KEY &&
  !SUPABASE_PUBLISHABLE_KEY.includes("YOUR_SUPABASE");

function showCounterError(which, message) {
  if (which === "live") {
    liveEl.textContent = "—";
    liveStatus.textContent = message;
  } else {
    totalEl.textContent = "—";
    totalStatus.textContent = message;
  }
}

async function setupVisitorCounters() {
  if (!configured || !window.supabase) {
    showCounterError("live", "Add your Supabase project settings in js/script.js");
    showCounterError("total", "Counter not configured yet");
    return;
  }
  const client = window.supabase.createClient(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY);
  const visitSessionKey = "nexus-visit-counted-v1";

  // Increment at most once per tab session. The database holds the shared count.
  if (!sessionStorage.getItem(visitSessionKey)) {
    const { error } = await client.rpc("increment_site_visits");
    if (error) {
      showCounterError("total", "Could not load shared counter — check Supabase setup");
      console.error("Visit counter error:", error.message);
    } else {
      sessionStorage.setItem(visitSessionKey, "1");
    }
  }
  const { data: total, error: totalError } = await client.rpc("get_site_visits");
  if (totalError) {
    showCounterError("total", "Could not load shared counter — check Supabase setup");
    console.error("Read counter error:", totalError.message);
  } else {
    totalEl.textContent = Number(total).toLocaleString();
    totalStatus.textContent = "Shared count from the database";
  }

  // Presence is ephemeral: it counts connected browser tabs, not unique humans.
  const sessionId = (window.crypto?.randomUUID?.() ||
    `${Date.now()}-${Math.random().toString(36).slice(2)}`);
  const channel = client.channel("nexus-gaming-live-visitors", {
    config: { presence: { key: sessionId } }
  });

  const updateLiveCount = () => {
    const state = channel.presenceState();
    const sessionKeys = new Set();
    Object.values(state).flat().forEach(payload => {
      if (payload && payload.session_id) sessionKeys.add(payload.session_id);
    });
    liveEl.textContent = sessionKeys.size.toLocaleString();
    liveStatus.textContent = "Connected browser sessions right now";
  };
  channel.on("presence", { event: "sync" }, updateLiveCount);
  channel.on("presence", { event: "join" }, updateLiveCount);
  channel.on("presence", { event: "leave" }, updateLiveCount);
  channel.subscribe(async status => {
    if (status === "SUBSCRIBED") {
      await channel.track({ session_id: sessionId, connected_at: new Date().toISOString() });
      updateLiveCount();
    } else if (status === "CHANNEL_ERROR" || status === "TIMED_OUT" || status === "CLOSED") {
      showCounterError("live", "Live presence unavailable — check Realtime settings");
      console.error("Presence channel status:", status);
    }
  });
  window.addEventListener("pagehide", () => { client.removeChannel(channel); }, { once: true });
}
setupVisitorCounters();
